# Geometric Eggbot plot
by dnewman

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:5423

Summary

More Eggbot plots. pattern2-767.svg is the nicest of the three. It was generated to be 1125 pixels high and then vertically shrunk to 66.667% of its original height. That then gives an egg-suitable aspect ratio.
The other two plots, pattern2-800.svg and pattern2-1000.svg are, respectively, 800 and 1000 pixels high. They are more appropriate for plotting on spheres as they have 1:1 aspect ratios. The supplied Python program generates the 800 pixel high variant. Change the HEIGHT variable setting for a 1000 pixel high plot.

Instructions

The vertical components are in layer 1 while the horizontal components are in layer 2. A top and bottom edge are in layer 3. Plotting just layers 1 and 3 also makes for an nice egg. You can plot the entire design with the "Plot" tab of the Eggbot Control extension. To plot layer-by-layer, use the "Layers" tab.
pattern2-767.svg has a fourth layer, "4 - test", which contains to small, horizontal tick marks. You can plot just this layer to get the picture nicely framed on your egg.
