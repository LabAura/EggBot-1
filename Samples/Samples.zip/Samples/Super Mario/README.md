# Super Mario Eggbot Egg
by nebarnix

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:2095503

Summary

The paths are somewhat messy.... Due to this it takes a while. Feel free to clean up if you have 4 hours of your life you will never get back!

Also, you should probably use a white egg, not a brown one. The sky looks a sickly grey. Maybe its just a winter inversion mario?
