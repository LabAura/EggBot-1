# Eggbot - Rocket
by R0b0Genius

http://www.thingiverse.com/thing:84660

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

4 Color-Layer Plot
1: Turquoise
2: Banana Clip Yellow
3: Red
4: Navy Blue

www.egg-bot.com
www.evilmadscientist.com
