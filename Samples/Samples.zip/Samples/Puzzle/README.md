# Eggbot Puzzle
by aevictory

<p align="center">
<img src="preview.JPG"/>
</p>

http://www.thingiverse.com/thing:660635

Summary

An Inkscape file for the Eggbot to make a puzzle.

http://shop.evilmadscientist.com/index.php

Instructions

Used homemade electric kistka. Pic is of undyed egg.
