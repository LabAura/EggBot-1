# Eggbot Peano-Gosper Curve 2
by peterinaz

<p align="center">
<img src="preview.JPG"/>
</p>

http://www.thingiverse.com/thing:1322635

Summary

This is actually a bunch of tiled Peano-Gosper curves. This is basically composed of three lines. Done with a Sakura Pigma Micron .005 pen. This is one of my favourite egg-bot patterns because it looks like it's alive when it's printing!

How I Designed This

L-System
I used the L-system function on Inkscape to generate the curve, then I manually scaled and tiled it into three rows.
