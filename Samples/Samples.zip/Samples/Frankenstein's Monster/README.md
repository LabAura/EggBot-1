# Eggbot - Frankenstein's Monster
by R0b0Genius

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:84654

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

4 Color-Layer Plot
1: Leg Warmer Yellow
2: Argyle Green
3: Red
4: Black

www.egg-bot.com
www.evilmadscientist.com
