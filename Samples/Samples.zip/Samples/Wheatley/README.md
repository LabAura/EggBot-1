# Eggbot - Wheatley
by R0b0Genius

http://www.thingiverse.com/thing:84653

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

5 Color-Layer Plot
1: Turquoise
2: Navy Blue
3: Slate Gray
4: Black
5: Black (Martha Stewart .1mm)

www.egg-bot.com
www.evilmadscientist.com

Wheatley A© Valve Corporation
