# Eggbot Pikatchu
by McOlf

<p align="center">
<img src="preview.JPG"/>
</p>

http://www.thingiverse.com/thing:760829

Summary

Eggbot plot with Pikatchu and a rabbit.
