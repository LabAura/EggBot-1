# Eggbot - Pokeball
by R0b0Genius

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:84656

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

3 Color-Layer Plot
1: Red
2: Slate Gray
3: Black

www.egg-bot.com
www.evilmadscientist.com

Pokeball A© PokA©mon/Nintendo

