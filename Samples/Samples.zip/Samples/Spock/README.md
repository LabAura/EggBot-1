# Eggbot Spock
by peterinaz

<p align="center">
<img src="preview.JPG"/>
</p>

http://www.thingiverse.com/thing:1322623

Summary

Is there anything that really needs to be said? Done with a Sakura Pigma Micron .005 pen.
