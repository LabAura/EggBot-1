# Eggbot - Oscar the Grouch
by R0b0Genius

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:84084

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

5 Color-Layer Plot
1: Orange
2: Rose
3: Argyle Green
4: Green
5: Black

www.egg-bot.com
www.evilmadscientist.com

Oscar the Grouch A© Sesame Workshop
