# Eggbot - AngryBird - Red Character
by ShaAli

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:29752

Summary

This is a svg file for Eggbot. My kids wanted it for their ping pong table :)
Its not perfect. But kids don't care as long as it looks like one

Instructions

Download the file, load a ping pong ball in the eggbot.
In Eggbot control panel select layers, start with layer 1 - Red
Change Pen according to layer.

Enjoy

Oh... Here a time-lapse video of it being egg-bottted
http://www.youtube.com/watch?v=YZG14IKqd4U&hd=1
