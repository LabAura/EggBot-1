# Eggbot - Koala with joey
by McOlf

<p align="center">
<img src="preview.JPG"/>
</p>

http://www.thingiverse.com/thing:755878

Summary

Designed for The Original Egg-Bot Kit.
Colors are black 0.6mm.

1: Black

www.egg-bot.com
www.evilmadscientist.com
