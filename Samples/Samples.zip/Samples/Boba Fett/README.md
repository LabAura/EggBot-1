# Eggbot - Boba Fett
by R0b0Genius

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:84088

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

6 Color-Layer Plot
1: Slate Gray
2: Banana Clip Yellow
3: Beige
4: Pomegranate
5: Earl Grey
6: Black

www.egg-bot.com
www.evilmadscientist.com

Boba Fett A© Disney

