# Pi-Egg for Eggbot
by thor4231

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:269809

Summary

Eggbot art in celebration of Pi Day. Made it last year and felt it was time to share it.
