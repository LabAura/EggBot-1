# Eggbot - Bisasam
by McOlf

<p align="center">
<img src="preview.JPG"/>
</p>

http://www.thingiverse.com/thing:760857

Summary

Plot of Bisasam and "Frohe Ostern" text.
