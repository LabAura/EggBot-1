# zipper template for eggbot
by schuetzi99

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:1981701

Summary

This is a template to print an zipper onto a egg.
https://youtu.be/jIhRP3eUceU
