# Imperial Crest Ornament for EggBot
by Lenore

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:1202925

Summary

This is the Imperial Crest logo formatted for Eggbot with an inset fill. Drawn with black ultra-fine point sharpie marker on a holiday ornament about 2.5 inches in diameter.

How I Designed This

This was made starting with Star Wars Silhouettes by vecteezy.com.
