# Eggbot - Grover
by R0b0Genius

http://www.thingiverse.com/thing:84078

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

5 Color-Layer Plot
1: Pink
2: Red
3: Navy Blue
4: Black

www.egg-bot.com
www.evilmadscientist.com

Grover A© Sesame Workshop
