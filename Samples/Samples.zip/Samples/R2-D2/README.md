# R2-D2 Eggbot Egg
by bfergus

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:2233788

Summary

Built this eggbot like this http://www.thingiverse.com/thing:299483. Making eggs. Next logical step- an egg that uses BOTH: the eggbot and printer! Here's a remixed egg stand that mimics R2D2 Legs, and an eggbot pattern for drawing an R2D2 Egg.

How I Designed This

For stand, a remix of a couple models. For the eggbot pattern, downloaded a papercraft R2D2 and converted to a multi layer svg= adding some hatching as appropriate.
