# Eggbot - The Brain
by R0b0Genius

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:85200

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

3 Color-Layer Plot
1: Peach
2: Red
3: Black

www.egg-bot.com
www.evilmadscientist.com

The Brain A© Warner Bros. Entertainment Inc
