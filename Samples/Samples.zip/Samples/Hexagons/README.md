# Eggbot Design - Hexagons
by MadMonkeyProjects

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:1240930

Summary

Simple Eepeating Hexagon Design
