# Eggbot - Stormtrooper
by FabLabEP

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:302943

SVG file ready to print on your Eggbot.

Layers:
1: Grey
2: Black
