# Eggbot - Tux the Penguin
by R0b0Genius

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:86924

Summary

Designed for The Original Egg-Bot Kit.
Colors are Sharpie Ultra Fine unless otherwise noted.

3 Color-Layer Plot
1: Leg Warmer Yellow
2: Slate Gray
3: Black

www.egg-bot.com
www.evilmadscientist.com

