# Signers Egg for Eggbot
by HooDat

<p align="center">
<img src="preview.jpg"/>
</p>

http://www.thingiverse.com/thing:18359

Summary

Signers of the Declaration plotted with the Eggbot.
Unable to find a suitable vector based file of the Declaration, I manually traced all 56 Signers in Illustrator, saving them as smoothed paths, then imported the entire document into Inkscape. Most of them follow the pen stroke that the original Signer probably followed in 1776.

Instructions

If plotting on a normal sized egg, use as fine a point as possible. I used a 0.03mm Copic Multiliner for the pictured egg.
On larger eggs (goose, for example) it will plot OK with the .2mm Micron (size 005).
